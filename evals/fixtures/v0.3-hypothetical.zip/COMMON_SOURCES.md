# 共同来源包（两组相同）
核验日期：2026-09-16。来源由本轮作者实际查阅，再共同供给两套假设产物；不是两个 AI 各自调研的记录。

S-001：Snipe-IT 官方 Overview。设备用唯一资产编号区分，借出/归还用于避免同一资产被重复分配。
https://snipe-it.readme.io/docs/overview

S-002：Snipe-IT 官方 checkout API 说明，包含预期归还时间和备注等参数。这只证明已有系统的字段实践，不证明本产品应照搬后端。
https://snipe-it.readme.io/reference/hardware-checkout

本任务的“单管理员本地”“部分归还”来自共同测试输入，不是来源资料声称。共享云端、二维码、提醒、付费租赁均不是必选功能。小规模可以先用表格，这是作者的替代方案判断，不伪装成用户研究。
